//This file will define the routes for the CRUD operations.



const express=require('express');
const router=express.Router();
let books=require("./bookData");

//post method
router.post('./books',(req,res)=>{
    const book= req.body;
    book.id = books.length + 1;
    books.push(book);
    res.status(200).send(book);

});

//put method(update)

router.put('/books/:id', (req,res)=>{
    const book=books.find(b => b.id === parseInt(req.params.is));
    if(!book){
        return res.status(404).send({error : 'Book not found'});
    }

    Object.assign(book,req.body);
    res.status(200).send(book);

});


//get method(fetch)

router.get('/books', (req,res)=>{
    res.status(200).send(books);
});

router.get('/books/:id',(req,res)=>{
    const book=books.find(b => b.id === parseInt(req.params.id));

    if(!book){
        res.status(404).send({
            error:'Book not found'
        });
    }
    res.status(200).send(book);
});


router.delete('/books/:id',(req,res)=>{
    const bookIndex=books.findIndex(b=> b.id ===parseInt(req.params.id));

    if(bookIndex===-1){
        return res.status(404).send({
            error : `Book not found`
        });
    }
    const deletedBook = books.splice(bookIndex,1);
    res.status(200).send(deletedBook);

});


module.exports=router;